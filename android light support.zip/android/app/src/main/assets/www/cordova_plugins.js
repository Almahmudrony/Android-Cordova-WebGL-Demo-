cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "cordova-plugin-canvas-gamepad.CDVGamepad",
    "file": "plugins/cordova-plugin-canvas-gamepad/www/CDVGamepad.js",
    "pluginId": "cordova-plugin-canvas-gamepad",
    "clobbers": [
      "CDVGamepad"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-whitelist": "1.3.3",
  "cordova-plugin-canvas-gamepad": "0.1.1"
};
// BOTTOM OF METADATA
});